import automata as at

at.dfa_model()

