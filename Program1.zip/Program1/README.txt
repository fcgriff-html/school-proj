*** 
Frederick C Griffin, 2021
Scheme program made for CS374
Dr. Mongan
***
My design was trial and error as I was not familiar with scheme. I did a lot of independent research as to how operations with scheme are done
I spent a lot of time on Stack Overflow looking at scheme code with if statements, as well as using Dr Mongan's cite for the intro into scheme
Since this assignment is pretty straightforward in terms of coding once you understand it on a conceptual level, it did not take too long to complete
I ran into some errors and after finding nothing helpful online I asked Dr. Mongan about the code and he led me in the right direction
I took about 4 hours in 1 shot to code this (granted it was some research within the timeframe, so about half of that was spent coding directly)
I enjoyed the project, it wasnt awfully hard but required a lot of thought and understanding which is fun!
